package com.nadikarim.submission3.utils


const val TOKEN = "token 6d39cc00b4b9b2408cf18f9048153c49f71e6b12"
const val ERROR_401 = "Bad Request"
const val ERROR_403 = "Forbidden"
const val ERROR_404 = "Not Found"
const val EXTRA_DATA = "extra_data"
const val EXTRA_FAVORITE = "extra_data"
const val EXTRA_NOTE = "extra_note"
const val EXTRA_POSITION = "extra_position"
const val TYPE_DAILY = "Daily Reminder"
const val EXTRA_MESSAGE = "message"
const val EXTRA_TYPE = "type"
const val AUTHORITY = "com.nadikarim.submission3"
const val SCHEME = "content"
const val PREFS_NAME = "SettingPrefs"
//6d39cc00b4b9b2408cf18f9048153c49f71e6b12
