package com.nadikarim.consumerapp.utils


const val TOKEN = "token 4c5b087d8f967fdfda3cbc967eca7ae13c33428d"
const val ERROR_401 = "Bad Request"
const val ERROR_403 = "Forbidden"
const val ERROR_404 = "Not Found"
const val EXTRA_DATA = "extra_data"
const val EXTRA_FAVORITE = "extra_data"
const val EXTRA_NOTE = "extra_note"
const val EXTRA_POSITION = "extra_position"